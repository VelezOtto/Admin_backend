      </div>
     </div>
      
    </div>
 
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.js"></script>
    <script type="text/javascript" charset="utf-8">
	
 $(document).ready(function() {
   $('#ghatable').dataTable();
 });
    </script>
  </body>
</html> 